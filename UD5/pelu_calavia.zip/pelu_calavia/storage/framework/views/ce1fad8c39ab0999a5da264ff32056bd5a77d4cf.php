<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h1>Servicio nº <?php echo e($service->id); ?></h1>


    <ul>
        <li>
            <strong>Código</strong>
            <?php echo e($service->code); ?>

        </li>
        <li>
            <strong>Nombre</strong>
            <?php echo e($service->name); ?>

        </li>
        <li>
            <strong>Descripcion</strong>
            <?php echo e($service->details); ?>

        </li>
        <li>
            <strong>Precio</strong>
            <?php echo e($service->price); ?>

        </li>
        <li>
            <strong>Tiempo</strong>
            <?php echo e($service->time); ?>

        </li>

    </ul>
    <a href="/services" class="btn btn-primary float-right">
                Volver
    </a>  
</body>
</html><?php /**PATH /var/www/html/resources/views/service/show.blade.php ENDPATH**/ ?>