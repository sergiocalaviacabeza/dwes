<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Servicios</title>
</head>
<body>

<h1>Lista de Servicios
</h1>

<a href="/services/create" class="btn btn-primary float-right">
                Añadir Nuevo Servicio
    </a><br><br>

<table border="1">
<tr>
    <th>Código</th>
    <th>Nombre</th>
    <th>Detalles</th>
    <th>Precio</th>
    <th>Tiempo</th>
</tr>
<?php $__empty_1 = true; $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
<tr>
    <td><?php echo e($service->code); ?> </td>
    <td><?php echo e($service->name); ?> </td>
    <td><?php echo e($service->details); ?> </td>
    <td><?php echo e($service->price); ?> </td>
    <td><?php echo e($service->time); ?> </td>
    <td> <a href="/services/<?php echo e($service->id); ?>">Ver</a></td>
    <td> <a href="/services/<?php echo e($service->id); ?>/edit">Editar</a></td>
    <td> <a href="/services/<?php echo e($service->id); ?>/destroy">Eliminar</a></td>
</tr>
<tr>

</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

<?php endif; ?>
</table>
<hr>

</body>
</html><?php /**PATH /var/www/html/resources/views/service/index.blade.php ENDPATH**/ ?>