<?php
#config/db.php
namespace Config;

const DSN = 'mysql:dbname=mvc;host=db;charset=utf8';
const USER = 'root';
const PASSWORD = 'password';
